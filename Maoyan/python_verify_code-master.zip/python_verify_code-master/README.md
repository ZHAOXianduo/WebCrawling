# python_verify_code

## 说明
	简单的使用selenuim and chromeDriver下载有滑动验证码的网站数据，来模拟人工验证的方法
	
## 文件说明
	/bin 文件夹下是下载时所需要的库文件，

